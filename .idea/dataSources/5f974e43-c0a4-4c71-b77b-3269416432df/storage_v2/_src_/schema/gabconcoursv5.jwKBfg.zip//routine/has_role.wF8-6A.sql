create
    definer = root@localhost function has_role(_user_id int, _role varchar(50)) returns tinyint(1)
    deterministic
    reads sql data
BEGIN
    DECLARE role_exists BOOLEAN;

    SELECT EXISTS(
        SELECT 1
        FROM user_roles
        WHERE user_id = _user_id
        AND role = _role
    ) INTO role_exists;

    RETURN role_exists;
END;

