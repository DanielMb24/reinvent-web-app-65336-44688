create definer = root@localhost view vue_candidatures_completes as
select `c`.`id`         AS `id`,
       `c`.`nupcan`     AS `nupcan`,
       `c`.`nomcan`     AS `nomcan`,
       `c`.`prncan`     AS `prncan`,
       `c`.`maican`     AS `maican`,
       `c`.`telcan`     AS `telcan`,
       `c`.`dtncan`     AS `dtncan`,
       `c`.`ldncan`     AS `ldncan`,
       `c`.`phtcan`     AS `phtcan`,
       `c`.`statut`     AS `statut`,
       `c`.`created_at` AS `created_at`,
       `co`.`libcnc`    AS `concours_nom`,
       `co`.`fracnc`    AS `concours_frais`,
       `f`.`nomfil`     AS `filiere_nom`,
       `e`.`nomets`     AS `etablissement_nom`,
       `n`.`nomniv`     AS `niveau_nom`
from ((((`gabconcoursv5`.`candidats` `c` left join `gabconcoursv5`.`concours` `co`
         on ((`c`.`concours_id` = `co`.`id`))) left join `gabconcoursv5`.`filieres` `f`
        on ((`c`.`filiere_id` = `f`.`id`))) left join `gabconcoursv5`.`etablissements` `e`
       on ((`co`.`etablissement_id` = `e`.`id`))) left join `gabconcoursv5`.`niveaux` `n`
      on ((`c`.`niveau_id` = `n`.`id`)));

