create definer = root@localhost trigger before_insert_participation
    before insert
    on participations
    for each row
BEGIN
  SET NEW.numero_candidature = CONCAT('GC', YEAR(CURDATE()), '-', LPAD(NEW.candidat_id, 4, '0'));
END;

