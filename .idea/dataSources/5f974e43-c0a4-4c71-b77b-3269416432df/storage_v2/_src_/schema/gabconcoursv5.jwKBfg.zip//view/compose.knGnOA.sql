create definer = root@localhost view compose as
select `n`.`id`          AS `id`,
       `n`.`candidat_id` AS `candidat_id`,
       `n`.`concours_id` AS `concours_id`,
       `n`.`matiere_id`  AS `matiere_id`,
       `n`.`note`        AS `notcomp`,
       `n`.`coefficient` AS `coefficient`,
       `c`.`nomcan`      AS `nomcan`,
       `c`.`prncan`      AS `prncan`,
       `co`.`libcnc`     AS `concours_nom`,
       `m`.`nom_matiere` AS `nom_matiere`
from (((`gabconcoursv5`.`notes` `n` join `gabconcoursv5`.`candidats` `c`
        on ((`n`.`candidat_id` = `c`.`id`))) join `gabconcoursv5`.`concours` `co`
       on ((`n`.`concours_id` = `co`.`id`))) join `gabconcoursv5`.`matieres` `m` on ((`n`.`matiere_id` = `m`.`id`)));

