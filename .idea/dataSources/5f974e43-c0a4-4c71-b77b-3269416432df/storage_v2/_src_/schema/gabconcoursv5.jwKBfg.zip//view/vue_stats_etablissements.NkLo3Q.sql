create definer = root@localhost view vue_stats_etablissements as
select `e`.`id`                                                    AS `id`,
       `e`.`nomets`                                                AS `nomets`,
       count(distinct `co`.`id`)                                   AS `nb_concours`,
       count(distinct `c`.`id`)                                    AS `nb_candidatures`,
       count((case when (`c`.`statut` = 'valide') then 1 end))     AS `nb_validees`,
       count((case when (`c`.`statut` = 'en_attente') then 1 end)) AS `nb_en_attente`,
       count((case when (`c`.`statut` = 'rejete') then 1 end))     AS `nb_rejetees`
from ((`gabconcoursv5`.`etablissements` `e` left join `gabconcoursv5`.`concours` `co`
       on ((`e`.`id` = `co`.`etablissement_id`))) left join `gabconcoursv5`.`candidats` `c`
      on ((`co`.`id` = `c`.`concours_id`)))
group by `e`.`id`, `e`.`nomets`;

